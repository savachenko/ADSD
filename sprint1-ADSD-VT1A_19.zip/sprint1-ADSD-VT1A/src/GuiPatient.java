public class GuiPatient extends Gui {


    static {
         StringShowInfo1="mijn gegevens inzien";
         StringShowInfo2="mijn gegevens aanpassen";
    }

 /*   StringShowInfo1="mijn gegevens inzien";
    StringShowInfo2="mijn gegevens aanpassen";*/

    public GuiPatient(Profile profile)
     {

         super(profile);
         super.k=1;
         System.out.println(k);

         //super();


     }

    public static void main(String[] args) {

        Profile profile1= new Profile ("Anna", "Janssen", 32,56.00,1.75);

        GuiPatient mytest=new GuiPatient(profile1);

    }


}
