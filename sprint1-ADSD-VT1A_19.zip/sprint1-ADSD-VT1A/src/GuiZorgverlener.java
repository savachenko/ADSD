


public class GuiZorgverlener extends Gui {


    static {
        StringShowInfo1="de gegevens van een patiënt inzien";
        StringShowInfo2="de gegevens van een patiënt aanpassen";
    }

 /*   StringShowInfo1="mijn gegevens inzien";
    StringShowInfo2="mijn gegevens aanpassen";*/

    public GuiZorgverlener (Profile profile)
    {
        super(profile);

        //super();


    }

    public static void main(String[] args) {

        Profile profile1= new Profile ("Anna", "Janssen", 32,56.00,1.75);

        GuiZorgverlener  mytest=new GuiZorgverlener (profile1);
    }


}