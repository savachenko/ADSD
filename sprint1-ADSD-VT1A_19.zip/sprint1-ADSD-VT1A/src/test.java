public class test {

    public static void main(String[] args) {

        //GuiPatient  myPatient =new GuiPatient();
       // GuiZorgverlener myZorverlener= new GuiZorgverlener();


    }
}
