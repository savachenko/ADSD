

public class start
{
    public static void main(String[] args) {

        Profile profile1 = new Profile("Anna", "Janssen", 32, 56.00, 1.75);

        CreateGui obj1 = new CreateGui(profile1, "test");


    }

}


